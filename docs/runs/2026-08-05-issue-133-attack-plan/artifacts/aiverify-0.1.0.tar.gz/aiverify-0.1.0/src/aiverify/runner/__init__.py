"""Runner primitives for Smoke Slice and M1 verification runs."""

from aiverify.runner.admission import (
    AdmissionResult,
    PlannedRunnerOptions,
    ProductionSeamAdmissionError,
    admit_production_seam,
    establish_and_abandon_temporary_record,
    verify_admitted_receipt,
    write_admission_receipt,
)
from aiverify.runner.codex_backend import (
    CodexCliBackend,
    CodexCliError,
    JourneyExecutionRequest,
    JourneyExecutionResult,
)
from aiverify.runner.command import CommandResult, CommandRunner, SubprocessCommandRunner
from aiverify.runner.evidence import AndroidEvidenceCollector, EvidenceCheckpoint
from aiverify.runner.journey import (
    JourneySegment,
    JourneySegmentFlow,
    JourneySegmentRunner,
    scenario_to_segments,
    segment_to_journey_xml,
)
from aiverify.runner.run_spec import (
    AssertionSpec,
    DryRunPlan,
    HostProjectLocator,
    RunSpec,
    RunSpecError,
    ScenarioSpec,
    SystemEventSpec,
    load_run_spec,
)
from aiverify.runner.system_events import (
    DeviceSystemEventInjector,
    SystemEventInjectionError,
)
from aiverify.runner.verdict import judge_l2_from_android_layout

__all__ = [
    "AdmissionResult",
    "AndroidEvidenceCollector",
    "AssertionSpec",
    "CodexCliBackend",
    "CodexCliError",
    "CommandResult",
    "CommandRunner",
    "DryRunPlan",
    "DeviceSystemEventInjector",
    "EvidenceCheckpoint",
    "HostProjectLocator",
    "JourneyExecutionRequest",
    "JourneyExecutionResult",
    "JourneySegment",
    "JourneySegmentFlow",
    "JourneySegmentRunner",
    "PlannedRunnerOptions",
    "ProductionSeamAdmissionError",
    "RunSpec",
    "RunSpecError",
    "ScenarioSpec",
    "SubprocessCommandRunner",
    "SystemEventSpec",
    "SystemEventInjectionError",
    "judge_l2_from_android_layout",
    "load_run_spec",
    "admit_production_seam",
    "establish_and_abandon_temporary_record",
    "scenario_to_segments",
    "segment_to_journey_xml",
    "verify_admitted_receipt",
    "write_admission_receipt",
]
